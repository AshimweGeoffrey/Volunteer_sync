﻿namespace Google.Maps.Places.Details
{
#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
	public enum AspectType
	{
		Appeal,
		Atmosphere,
		Decor,
		Facilities,
		Food,
		Overall,
		Quality,
		Service
	}
#pragma warning restore CS1591 // Missing XML comment for publicly visible type or member
}